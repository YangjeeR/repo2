package myproject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import static org.junit.Assert.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class googleverify {
	
	WebDriver driver;
	public void google()
			{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Acer\\Desktop\\selenium\\chromedriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.id("_eEe")).click();
		//driver.findElement(By.name("q")).sendKeys("selenium");
			
	
	//public void test()
	//{
		
		
		WebElement searchBox=driver.findElement(By.name("q"));
	     assertTrue("Verification Failed:Search box is not displayed.",searchBox.isDisplayed());
		searchBox.clear();
		searchBox.sendKeys("selenium");
		 // Capture Search Auto Suggestions
        List<WebElement> listBox = driver.findElements(By.xpath("//div//div//ul[@role='listbox']//li"));
        int listBoxSize = listBox.size();
        System.out.println("The size of the listbox is:"+listBoxSize);
        ArrayList<String> listBoxItems = new ArrayList<String>();
        for (WebElement option : listBox)
        {
              listBoxItems.add(option.getText());
        }
        // ArrayList to store expected Test data
        ArrayList<String> expectedItems = new ArrayList<String>();
        expectedItems.add("selenium ide");
        expectedItems.add("selenium tutorial");
        expectedItems.add("selenium webdriver");
        expectedItems.add("selenium");
        // Compare the ArrayLists
        assertTrue("Verification Failed: The correct options are not being dispalyed.",expectedItems.toString().contentEquals(expectedItems.toString()));
        // Verify and Click on the Submit Button
        WebElement submitButton = driver.findElement(By.xpath("//div[@class='sbqs_c']"));
        assertTrue("Verification Failed: Submit button is not being displayed.",submitButton.isDisplayed());
        submitButton.click();
        // Verify that the first result for Selenium HQ website is shown and Click on it
        WebElement seleniumHQLink = driver.findElement(By.linkText("Selenium - Web Browser Automation"));
        assertTrue("Verification Failed: Selenium HQ website link is not shown.",seleniumHQLink.isDisplayed());
        seleniumHQLink.click();
        // Verify that the user is redirected to the Selenium's Official Website
        //assertTrue("Verification Failed: User is redirected to a wrong page.",(driver.getCurrentUrl().equals("http://www.seleniumhq.org/"))&&(driver.getTitle().equals("Selenium - Web Browser Automation")));
        // Navigate back to the Google Search Engine Webpage
       
        if(driver.getTitle().equals("Selenium - Web Browser Automation"))
        {
        	System.out.print("passed");
        	
        }
        
        else 
        {
        	System.out.print("failed");
        	
        }
        driver.quit();
}
	
	public void tearDown() {
		driver.quit();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		googleverify obj=new googleverify();
		obj.google();
		//obj.test();
		obj.tearDown();
	}

}
