package myproject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class checkVisibility {
	WebDriver driver;
	
	public void setUp()

	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Acer\\Desktop\\selenium\\chromedriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		//launch browser
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		//check title
		if(driver.getTitle().equals("Google"))
		{
			System.out.println("Google search is displayed");
		}
		else 
		{
			System.out.println("Google search is not displayed");
		}
		
		driver.quit();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		checkVisibility obj=new checkVisibility();
		obj.setUp();

	}

}
