package myproject;

import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class dropdown {
	
	WebDriver driver;
	
	public void setup() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Acer\\Desktop\\selenium\\chromedriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("file:///C:/Users/Acer/Documents/dropdown.html");
		driver.manage().window().maximize();
		
		driver.findElement(By.linkText("Google")).click();
		driver.navigate().back();
		Thread.sleep(2000);
		
		Select selectByValue = new Select(driver.findElement(By.id("SelectID_One")));
		 selectByValue.selectByValue("greenvalue");
		 Thread.sleep(5000);
		 
	  Select selectbyvisibletext=new Select(driver.findElement(By.id("SelectID_Two")));
	  selectbyvisibletext.selectByVisibleText("Lime");
	  Thread.sleep(2000);

	  Select selectbyindex=new Select(driver.findElement(By.id("SelectID_Three")));
	  selectbyindex.selectByIndex(2);
	  Thread.sleep(2000);
 
	}

	public void tearDown() {
		driver.quit();
		
	}

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		dropdown obj=new dropdown();
		obj.setup();
		obj.tearDown();
	
	}
}
