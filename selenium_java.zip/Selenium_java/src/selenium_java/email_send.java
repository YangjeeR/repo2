package selenium_java;

public class email_send {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
