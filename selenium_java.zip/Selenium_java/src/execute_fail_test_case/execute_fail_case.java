package execute_fail_test_case;

import org.testng.annotations.Test;

public class execute_fail_case {
	@Test
	public void FirstTest() {
		// TODO Auto-generated method stub
		

	System.out.print("My first test case");

	}

}
