package execute_fail_test_case;

import org.testng.Assert;
import org.testng.annotations.Test;

public class execute_fail_case3 {
	@Test
	public void ThirdTest() {
		// TODO Auto-generated method stub
		
    Assert.assertTrue(false);
	System.out.print("My Third test case");

	}

}
