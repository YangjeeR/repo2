package appium.test;


import java.net.MalformedURLException;
import java.net.URL;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;


public class calculator {
WebDriver driver;
String path;

public void setUp() throws MalformedURLException{
	//Set up desired capabilities and pass the Android app-activity and app-package to Appium
	path=System.getProperty("user.dir");
	DesiredCapabilities cap=new DesiredCapabilities();
	cap.setCapability("PlatformName", "Android");
	cap.setCapability("deviceName", "192.168.188.101:5555");
	cap.setCapability("app",path+"\\app\\ApiDemos.apk");
	cap.setCapability("appPackage", "com.android.calculator2");
	cap.setCapability("appActivity", "com.android.calculator2.Calculator");

//Create RemoteWebDriver instance and connect to the Appium server
 //It will launch the Calculator App in Android Device using the configurations specified in Desired Capabilities
	driver= new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"),cap);
}


public void testCal() throws Exception {
   //locate the Text on the calculator by using By.name()
	   System.out.println("started");
   WebElement two=driver.findElement(By.id("com.android.calculator2:id/digit_7"));
   two.click();
   System.out.println(two);
   WebElement plus=driver.findElement(By.id("com.android.calculator2:id/op_add"));
   plus.click();
   WebElement four=driver.findElement(By.id("com.android.calculator2:id/digit_2"));
   four.click();
   WebElement equalTo=driver.findElement(By.id("com.android.calculator2:id/eq"));
   equalTo.click();
   //locate the edit box of the calculator by using By.tagName()
   WebElement results=driver.findElement(By.id("com.android.calculator2:id/result"));
	//Check the calculated value on the edit box
assert results.getText().equals("9"):"Actual value is : "+results.getText()+" did not match with expected value: 9";

}


public void teardown(){
	//close the app
	driver.quit();
}
public static void main(String[] args) throws Exception {
	// TODO Auto-generated method stub
	calculator obj=new calculator();
	obj.setUp();
	obj.testCal();
	obj.teardown();
}
}
