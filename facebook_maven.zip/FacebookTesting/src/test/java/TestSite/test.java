package TestSite;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test {

	WebDriver driver;
	@Given("^opened browser$")
	public void start_app()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Acer\\Desktop\\selenium\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://www.facebook.com/");
		

}
	
	
	@When("^enter username and password$")

	   public void fill_username() throws InterruptedException {
		String email[]= {"Username1","Username2","juliet_coke@yahoo.com"};
		String pass[]= {"Pass1","Pass2","123444"};
		for(int i=0;i<3;i++)
		{

	      driver.findElement(By.id("email")).sendKeys(email[i]);

	      driver.findElement(By.id("pass")).sendKeys(pass[i]);
	      driver.findElement(By.id("loginbutton")).click();
	  }
	}
	  
	
	  @Then("^Click Login$")

	   public void click_login() throws InterruptedException {
	      String verifyid;
			verifyid = driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[1]/div/div[2]/div[1]/div/div/div/div/div/div/div[1]/ul/li/a/div")).getText();
			if(verifyid.contains("Yangzee Thulung Rai Shrestha"))

	      {
	    	  System.out.println("Successfull");
	    	  
	      }
	      else 
	      {
	    	  System.out.println("Login failed");
	      }
	      driver.close();
	  
}
}