package javatutorial;

public class EvenNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a;
		
		for(a=1;a<=10;a++) {
			
			if(a%2==0)
			{
			
			System.out.println("The list of even numbers from 1 to 100  " + a);
		}
			


		}
	}

}
