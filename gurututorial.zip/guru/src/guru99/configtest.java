package guru99;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;


public class configtest {

	public void testConfig() throws Exception  
	{
		File src=new File("C:\\Users\\Acer\\eclipse-workspace\\guru\\config.property");
		FileInputStream fis=new FileInputStream(src);
		Properties prop=new Properties();
		prop.load(fis);
		String path=prop.getProperty("ChromeDriver");
		System.out.println(path);
	}
	
	public static void main (String[] args) throws Exception
	{
		configtest obj=new configtest();
				obj.testConfig();
	
}

}