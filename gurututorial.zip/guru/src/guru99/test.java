package guru99;

import java.io.File;

//import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import utility.ConfigReader;

import org.apache.commons.io.FileUtils;

public class test{
	
	 
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		ConfigReader path=new ConfigReader();
		//Setup chrome driver    
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\Acer\\Desktop\\selenium\\chromedriver\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver",path.getChromePath());
		WebDriver driver=new ChromeDriver();
    	String baseUrl = "http://www.demo.guru99.com/V4/";
    	
    	// launch chrome and direct it to the Base URL
    	driver.get(baseUrl);


	   try { // Enter username
	    driver.findElement(By.name("uid")).sendKeys("mngr92993 ");

	    // Enter Password
	    driver.findElement(By.name("password")).sendKeys("EterAza");
   
	    // Click Login
	    driver.findElement(By.name("btnLogin")).click();
	    File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        System.out.println(scrFile);
     //The below method will save the screen shot in d drive with name "screenshot.png"
        FileUtils.copyFile(scrFile, new File("C:\\Users\\Acer\\Desktop\\selenium\\screenshot\\screenshot.png"));
	    //verify the title of homepage
	    //Assert.assertEquals("Guru99 Bank Manager HomePage" , driver.getTitle());
		 
	    
	    //System.out.println("login sucessfull");


   		  String actualTitle;
   	  
	 	actualTitle = driver.getTitle();
			if (actualTitle.contains("Guru99 Bank Manager HomePage")) {
					    System.out.println("Test case: Passed");
			} 
			else {
					    System.out.println("Test case : Failed");
			}
			
			
			//check manager id is equal to username
			String verifyid;
			verifyid = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[3]/td")).getText();
			System.out.println(verifyid);
				if (verifyid.contains("mngr92993")) {
						    System.out.println("Test case: Passed");
				} 
				else {
						    System.out.println("Test case : Failed");
				}
				 
				Thread.sleep(2000);
			
			    driver.quit();	
	   }
	   catch (Exception e){
 		  System.out.println("Screenshot cannot be taken");
 		
	   }
	}
	
	    
	    
	    /*public static void getscreenshot() throws Exception 
	      {
	    	WebDriver driver=new ChromeDriver();
	    	
	              
	      }    */

	

}
