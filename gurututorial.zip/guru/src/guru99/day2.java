package guru99;


import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;


public class day2 {
	static String baseUrl;
	
   
   public static void main(String[] args) throws Exception {
	   System.setProperty("webdriver.chrome.driver","C:\\Users\\Acer\\Desktop\\selenium\\chromedriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		baseUrl = "http://www.demo.guru99.com/V4/";
		driver.get(baseUrl);
		
		File src = new File("C:\\Users\\Acer\\Desktop\\selenium\\exceldata\\gurutest.xlsx");
		FileInputStream fis=new FileInputStream(src);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		
		XSSFSheet sheet1=wb.getSheetAt(0);
		int rowcount=sheet1.getLastRowNum();
		
		
	for (int i=1;i<=rowcount;i++)
		{
		
		DataFormatter formatter = new DataFormatter();
		 Cell cell = sheet1.getRow(i).getCell(0);
		 String data0 = formatter.formatCellValue(cell);
		 Cell cell1 = sheet1.getRow(i).getCell(1);
		 String data1 = formatter.formatCellValue(cell1);
		 
		//String data0=sheet1.getRow(i).getCell(0).getStringCellValue();
		//String data1=sheet1.getRow(i).getCell(1).getStringCellValue();
		 // Enter username
	    driver.findElement(By.name("uid")).sendKeys(data0);

	    // Enter Password
	    driver.findElement(By.name("password")).sendKeys(data1);
   
	    // Click Login
	    driver.findElement(By.name("btnLogin")).click();
	    
	    
	   /* driver.findElement(By.name("uid")).sendKeys(sheet1.getRow(i).getCell(0).getStringCellValue());
	    driver.findElement(By.name("password")).sendKeys(sheet1.getRow(i).getCell(1).getStringCellValue());
	    driver.findElement(By.name("btnLogin")).click();*/
	   /* System.out.println(i);
	    System.out.println(data0);
	    System.out.println(data1);*/
	    driver.switchTo().alert().accept();
        
		} 
		
		
	    wb.close();
	    String actualTitle;
	 	actualTitle = driver.getTitle();
			if (actualTitle.contains("Guru99 Bank Manager HomePage")) {
					    System.out.println("Test case: Passed");
			} 
			else {
					    System.out.println("Test case : Failed");
			}
	    Thread.sleep(2000);
		  driver.close();

    }
	    
}
