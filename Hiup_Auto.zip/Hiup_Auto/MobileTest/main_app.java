package MobileTest;

import java.io.IOException;

import org.testng.annotations.Test;

import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

public class main_app extends Setup{

Setup obj=new Setup();

@Test
public void login_test() throws InterruptedException, IOException, RowsExceededException, WriteException
{
	obj.setup_server();
	obj.login("jmeter1234@gmail.com", "y@nzEE2018");
	obj.logout();
	obj.Signup();
    obj.forget();

}
}




