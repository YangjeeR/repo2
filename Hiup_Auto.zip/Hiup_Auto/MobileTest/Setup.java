package MobileTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDeviceActionShortcuts;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidKeyCode;
import jxl.write.Label;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;
import MobileTest.ElementsPath;

public class Setup extends ExcelCode{
	
	AppiumDriver<MobileElement> driver;
	String path;
	ElementsPath obj=new ElementsPath();
	static String label;

public void setup_server() throws RowsExceededException, WriteException, IOException, InterruptedException
{

	System.out.println("Session is creating");

 path=System.getProperty("user.dir");
 DesiredCapabilities cap=new DesiredCapabilities();
 cap.setCapability("platformName","Android");
// cap.setCapability("deviceName","192.168.188.102:5555");
 cap.setCapability("deviceName", "04157df411343e15");
 cap.setCapability("autoAcceptAlerts",true);
 cap.setCapability("noReset",true);
 cap.setCapability("app",path+"\\app\\Hiup_2.2.1_65.apk");

 try
 {
 driver= new AndroidDriver<MobileElement>(new URL("http://0.0.0.0:4723/wd/hub"),cap);
 System.out.println("Session is created");
 driver.manage().timeouts().implicitlyWait(4000,TimeUnit.SECONDS);
 MobileElement job=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/openings_job_label"));
 String title=job.getText();
 if(title.equals("Jobs"))
 {
  label="Pass";
 }
 else
 {
 label="Fail";
	 
 }
 System.out.println(label);
 driver.manage().timeouts().implicitlyWait(4000,TimeUnit.SECONDS);
 
 sheet.getRow(1).getCell(4).setCellValue(label);

 }
 catch(MalformedURLException e)
 {
	 e.printStackTrace();
 }
 
 
}


//(priority=2,description="TestCase2 - User login.")
public void login(String user,String pass)
{
	try
	{
    driver.manage().timeouts().implicitlyWait(200,TimeUnit.SECONDS);
	MobileElement control=driver.findElement(By.xpath(obj.control_btn1));
	control.click();//control button
	
	MobileElement menu=driver.findElement(By.xpath(obj.main_menu2));
	menu.click();//main menu button
	
	MobileElement profile=driver.findElement(By.xpath(obj.profile));
	profile.click();//profile button
	
	MobileElement login=driver.findElement(By.xpath("//android.widget.Button[@text='Login']"));
	login.click(); 
	
	MobileElement email=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/email"));
	email.sendKeys(user);	
	
	MobileElement passw=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/password"));
	passw.sendKeys(pass);	
	
	Thread.sleep(2000);
	
	MobileElement clk_btn=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/sign_in_button"));
	clk_btn.click();
	Thread.sleep(3000);
	
	MobileElement title= driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/tv_user_profile_email_address"));
	String t=title.getText();
	
	
	if(t.equals(user))
	{
		System.out.print(user + " has succcessfully logged in.");
		label="Pass";
	}
	
	else
	{
		System.out.print("Unable to login.");
		label="Fail";
		
	}
	 driver.manage().timeouts().implicitlyWait(4000,TimeUnit.SECONDS);
	sheet.getRow(2).getCell(4).setCellValue(label);

	}
	
	catch(Exception e)
	{
		e.getMessage();
	}
	

}

public void logout() throws InterruptedException
{
	
MobileElement edit=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/bt_edit"));
edit.click();

driver.navigate().back();

driver.manage().timeouts().implicitlyWait(200,TimeUnit.SECONDS);
MobileElement control=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/control_hint"));
control.click();//control button

MobileElement menu=driver.findElement(By.xpath(obj.main_menu2));
menu.click();//main menu button
driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS); 

/*MobileElement menu1=driver.findElement(By.xpath(obj.main_menu));
menu1.click();//main menu button
*/
System.out.println("test");

MobileElement log=driver.findElement(By.xpath(obj.log));
log.click();

MobileElement log_yes=driver.findElement(By.id("android:id/button1"));
log_yes.click();//Yes

String link="Refine";

if(link.equals("Refine"))
{
label="Pass";
}
else
{

label="Fail";
	
}
sheet.getRow(3).getCell(4).setCellValue(label);
}

public void Signup() throws InterruptedException, IOException
{
	driver.manage().timeouts().implicitlyWait(200,TimeUnit.SECONDS);
	MobileElement control=driver.findElement(By.xpath(obj.control_btn1));
	control.click();//control button
	
	MobileElement menu=driver.findElement(By.xpath(obj.main_menu1));
	menu.click();//main menu button
	
	MobileElement profile=driver.findElement(By.xpath(obj.profile));
	profile.click();//profile button
	
	MobileElement signup=driver.findElement(By.xpath(obj.signup));
	signup.click(); 
	File src = new File("C:\\Users\\Acer\\Desktop\\selenium\\exceldata\\appiumsignup.xlsx");
	FileInputStream fis=new FileInputStream(src);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	String data0 = null;
	String data6 = null;
	String data7 = null;
	XSSFSheet sheet1=wb.getSheetAt(0);
	int rowcount=sheet1.getLastRowNum();
	for (int i=1;i<=rowcount;i++)
	{
	
	DataFormatter formatter = new DataFormatter();
	 Cell cell = sheet1.getRow(i).getCell(0);
	 data0 = formatter.formatCellValue(cell);
	 Cell cell1 = sheet1.getRow(i).getCell(1);
	 String data1 = formatter.formatCellValue(cell1);
	 Cell cell2 = sheet1.getRow(i).getCell(2);
	 String data2 = formatter.formatCellValue(cell2);
	 System.out.println(data2);
	 Cell cell3 = sheet1.getRow(i).getCell(3);
	 String data3 = formatter.formatCellValue(cell3);
	 Cell cell4 = sheet1.getRow(i).getCell(4);
	 String data4 = formatter.formatCellValue(cell4);
	 System.out.println(data4);
	 Cell cell5 = sheet1.getRow(i).getCell(5);
	 String data5 = formatter.formatCellValue(cell5);
	 Cell cell6 = sheet1.getRow(i).getCell(6);
	 data6 = formatter.formatCellValue(cell6);
	 Cell cell7 = sheet1.getRow(i).getCell(7);
	 data7 = formatter.formatCellValue(cell7);

	 
	 
	MobileElement email=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_sign_up_email_address"));
	email.sendKeys(data0);
	MobileElement email2=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_sign_up_confirm_email_address"));
	email2.sendKeys(data1);//confirm email
	((AndroidDeviceActionShortcuts) driver).pressKeyCode(AndroidKeyCode.ENTER);
	
	MobileElement first=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_sign_up_firstname"));
	first.sendKeys(data2);
	((AndroidDeviceActionShortcuts) driver).pressKeyCode(AndroidKeyCode.ENTER);
	MobileElement last=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_sign_up_lastname"));
	last.sendKeys(data3);
	((AndroidDeviceActionShortcuts) driver).pressKeyCode(AndroidKeyCode.ENTER);
	MobileElement pass=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_sign_up_password"));
	pass.sendKeys(data4);
	((AndroidDeviceActionShortcuts) driver).pressKeyCode(AndroidKeyCode.ENTER);
	MobileElement pass2=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_sign_up_confirm_password"));
	pass2.sendKeys(data5);
	((AndroidDeviceActionShortcuts) driver).pressKeyCode(AndroidKeyCode.ENTER);
	wb.close();
	MobileElement check_box=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/sign_up_agree_checkbox"));
	check_box.click();
	verticalSwipe();
	MobileElement btn=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/bt_continue_sign_up"));
	btn.click();
	
	}
	
	MobileElement num=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_validation_number_country_number"));
	num.sendKeys("12");
	MobileElement mob=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_mobile_number"));
	mob.sendKeys("98099999");
	((AndroidDeviceActionShortcuts) driver).pressKeyCode(AndroidKeyCode.ENTER);
	Thread.sleep(1000);
	verticalSwipe();
	MobileElement submit=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/submit_button"));
	submit.click();//finish
	
	
	String login=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/tv_user_profile_email_address")).getText();
	
	if(login.equals(data0))
	{
		System.out.println("Login successful");
		MobileElement edit=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/bt_edit"));
		edit.click();
		MobileElement title=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_edit_user_profile_title"));
		title.sendKeys(data6);
		verticalSwipe();
		MobileElement about=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_user_profile_about_me"));
		about.sendKeys(data7);	
		MobileElement save=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/bt_save_edit_profile"));
		save.click();
		System.out.println("Profile has been successfully updated");
		label="Pass";
	}
	
	else
	{
		System.out.println("User cannot be created.Issue in login.");
		label="Fail";
	}
	sheet.getRow(4).getCell(4).setCellValue(label);
	 driver.manage().timeouts().implicitlyWait(2000,TimeUnit.SECONDS);
}

public void verticalSwipe() {
	
	Dimension dim=driver.manage().window().getSize();
	int height=dim.getHeight();
	int width=dim.getWidth();
	int x= width/2;
	int starty=(int)(height*0.80);
	int endy=(int)(height*0.20);
	driver.swipe(x, starty, x, endy, 500);
}

public void forget()
{
    driver.manage().timeouts().implicitlyWait(200,TimeUnit.SECONDS);
    MobileElement control=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/control_hint"));
    control.click();//control button
    
	MobileElement menu=driver.findElement(By.xpath(obj.main_menu1));
	menu.click();//main menu button
	
	MobileElement profile=driver.findElement(By.xpath("//android.widget.CheckedTextView[@text='Profile']"));
	profile.click();//profile button
	
	MobileElement login=driver.findElement(By.xpath("//android.widget.Button[@text='Login']"));
	login.click(); 
	
	MobileElement forget=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/forgotten_password"));
	forget.click();//forget button
	
	MobileElement reset_email=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/et_email_reset_password"));
	reset_email.sendKeys("jmeter1234@gmail.com");
	
	driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS); 
	
	MobileElement title=driver.findElement(By.id("co.olivemedia.hihoandroidwebapp:id/alertTitle"));
	String til=title.getText();
	
	MobileElement btn_ok=driver.findElement(By.id("android:id/button1"));
	btn_ok.click();
	
	if(til.equals("Email sent"))
	{
		label="Pass";
		
	}
	
	else
	{
	 label="Fail";
			
	}
	
	sheet.getRow(5).getCell(4).setCellValue(label);
	
}



public void valid_signin()
{
	
}


}
