package OliveCMS;

import org.testng.annotations.Test;

public class Master_TestCase {

@Test
public void login_Test()
{
Login_Page login=new Login_Page();
login.Setup();
}



}
