package OliveCMS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class ExcelTest {
	XSSFWorkbook wb1;
	XSSFSheet sh1;
	
@BeforeMethod
public void read()

{
	try
	{
		File src=new File("C:\\Users\\Acer\\Desktop\\selenium\\exceldata\\Olive CMS-Test Case.xlsx");
	FileInputStream fis=new FileInputStream(src);
	wb1 =new XSSFWorkbook(fis);
    sh1= wb1.getSheetAt(0); 
	}
	
	catch(Exception e)
	{
	 System.out.println("Issue in reading file " + e.getMessage());
	}
	
	
}

@AfterMethod
public void write()
{
	try
	{
		FileOutputStream fos =new FileOutputStream("C:\\Users\\Acer\\Desktop\\selenium\\exceldata\\Olive CMS-Test Case.xlsx");
	    wb1.write(fos);
	    wb1.close();
	}
	
	catch(Exception e)
	{
	 System.out.println("Issue in readind file " + e.getMessage());
	}
	
}
}
