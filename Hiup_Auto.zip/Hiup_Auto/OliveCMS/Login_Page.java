package OliveCMS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utility.Config_Reader;

public class Login_Page extends ExcelTest{
	
	WebDriver driver;
	String label;
	int numrow;
@BeforeMethod
	public void Setup()
	{
		Config_Reader config=new Config_Reader();
		System.setProperty("webdriver.chrome.driver",config.getChromePath());
		driver=new ChromeDriver();
		driver.get(config.getURL());
	}
	
	//login form
@Test(dataProvider="testdata")
	public void login(String user,String pass) throws InterruptedException
	{
	 System.out.println(user);
	 System.out.println(pass);
	    driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div/div/div[2]/form/div[1]/div/input")).sendKeys(user);
		driver.findElement(By.id("password")).sendKeys(pass);
		driver.manage().timeouts().implicitlyWait(2000,TimeUnit.SECONDS);	
		driver.findElement(By.xpath("//*[@id=\"app\"]/div/div/div/div/div[2]/form/div[4]/div/button")).click();
		
		Thread.sleep(5000);
       
		String user1="Yangjee";
		String pass1="123";
		
		if(user.equals(user1) & pass1.equals(pass1))
		{
	
		String dash= driver.findElement(By.xpath("//*[@id=\"page-wrapper\"]/section[2]/div/div/div/div/div[1]")).getText();
		if(dash.equalsIgnoreCase("dashboard"))
		 {
			 System.out.println("User has successfully logged in.");
			 label="Pass";	
			 logout();
		 }
		
		   else
		    {
			 System.out.println("User login is successfull");
			 label="Fail";
		     }

		}
		
		else 
	{
			String dash1=driver.findElement(By.xpath("//div[@class='panel-heading']")).getText();
			if(dash1.equalsIgnoreCase("Login"))
	
     {
	 System.out.println("User unable to logged in");
	 label="Pass";
	 		 		
    }

    else
    {
	 System.out.println("User login is successfull");
	 label="Fail";
     }
	}	
   
		 teardown();
    // sh1.getRow(2).getCell(4).setCellValue(label);	
     	

		 
}
	
	
	
public void logout()
{
	driver.findElement(By.xpath("//*[@id=\"app-navbar-collapse\"]/ul[2]/li/a")).click();
	driver.findElement(By.xpath("//*[@id=\"app-navbar-collapse\"]/ul[2]/li/ul/li[1]/a")).click();
	driver.findElement(By.xpath("/html/body/div/div[1]/a[1]")).click();
}

@DataProvider(name="testdata")
public Object[][] TestDataFeed() throws IOException{
 

 
	File src=new File("C:\\Users\\Acer\\Desktop\\selenium\\exceldata\\login_data.xlsx");
	FileInputStream fis=new FileInputStream(src);
	XSSFWorkbook wb1 =new XSSFWorkbook(fis);
	XSSFSheet sh1= wb1.getSheetAt(0); 
   // numrow=  sh1.getPhysicalNumberOfRows();
 
Object[][] data=new Object[3][2];
 
// This will run a loop and each iteration  it will fetch new row
for(int i=0;i<data.length;i++)
{
// Fetch first row username
data[i][0]=sh1.getRow(i).getCell(0).getStringCellValue();
// Fetch first row password
Cell cell1 = sh1.getRow(i).getCell(1);  
cell1.setCellType(Cell.CELL_TYPE_STRING);
data[i][1]=cell1.getStringCellValue();
 
}
return data;


}

public void teardown()
{
	driver.quit();
}
}
