package POM;

import org.openqa.selenium.By;
import MobileTest.ElementsPath;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;


public class Forget_Page extends Login_Page{
	
	AppiumDriver<MobileElement> driver;
	 ElementsPath obj=new ElementsPath();
	 Login_Page Login_obj;
	 
	 By forget=By.id(obj.forget);
	 By reset_email=By.id(obj.reset);
	 By reset_til=By.id(obj.reset_til);
	 By reset_ok=By.id(obj.reset_ok);
	 By reset_btn=By.id(obj.reset_btn);
	 By close=By.id(obj.close);
	 
	 
	public Forget_Page(AppiumDriver<MobileElement> driver2) {
		super(driver2);
		this.driver=driver2;
	}
	public void clickforget()
	{
		driver.findElement(forget).click();
	}
	public void reset_email(String email)
	{
		driver.findElement(reset_email).sendKeys(email);
	}
	public String getresettil()
	{
		return driver.findElement(reset_til).getText();
	}
	public void reset_ok()
	{
		driver.findElement(reset_ok).click();
	}
	
	public void reset_btn()
	{
		driver.findElement(reset_btn).click();
		
	}
	
	public void clickclose()
	{
		driver.findElement(close).click();
		
	}
	
	 public void forget(String email)
	 {
	 clickcontrol();
	 clickmenu();
	 clickprof();
	 clicklogin();
	 this.clickforget();
	 this.reset_email(email);
	 this.reset_btn();
	 }


}
